#import <Foundation/NSFileCoordinator.h>

@implementation NSFileAccessIntent
@end

@implementation NSFileCoordinator
@end
